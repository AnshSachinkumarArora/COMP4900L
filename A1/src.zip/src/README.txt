1) The animation provided hits all the requirements mentioned in the spec -
R0 - The assignment is in c++
R1 - There is a credits scene that rolls for the first 3 seconds
R2 - All 3 characters have different colors
R3 - The background has a static rectangular "wall"
R4 - The square rotates
R5 - The characters all move through functions so the path contains significantly more than 30 points
R6 - The characters all move at their own distinct non constant speeds
R7 - When the square touches the wall, the wall changes color
R8 - The code is commented
R9 - The circle moves with an erratic noise function